<div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light">ADMIN - SIPAPAH</div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.home') }}">DAFTAR PESANAN</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.profiluser') }}">TABEL USER</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.profiladmin') }}">TABEL ADMIN</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.kreasi') }}">TABEL KREASI</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.notifikasi') }}">TABEL NOTIFIKASI</a>
                    
                    <!-- <a class="list-group-item list-group-item-action list-group-item-light p-3" href="{{ route('admin.manage.layanan') }}">Layanan-User</a> -->
                </div>
            </div>